<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "tcc";


$conn = new PDO("mysql: host=$host; dbname=$dbname", $user, $pass);
