<?php

function component($nomeproduto, $valorproduto, $imgproduto, $idproduto, $desc){
    $element="
    <div class=\"item\">
                <form>
                  <div class=\"card\">
                    <div class=\"imgBx\">
                    <img src=\"../img/perfumes/$imgproduto\">
                      <ul class=\"action\">                       
                        <li>
                        <a type=\"button\" class=\"btn\" data-toggle=\"modal\" data-target=\"#aviso\"><i class=\"fa fa-shopping-cart\"></i></a>
                          <span>Adicionar</span>
                        </li>
                        <li>
                        <a type=\"button\" class=\"btn\" data-toggle=\"modal\" data-target=\"#ver\" data-nome='$nomeproduto' data-valor='$valorproduto' data-img='$imgproduto' data-desc='$desc'><i class=\"fa fa-eye\"></i></a>
                          <span>Ver detalhes</span>
                        </li>
                      </ul>
                    </div>
                    <div class=\"content\">
                      <div class=\"productName\">
                        <h2>$nomeproduto</h2>
                      </div>             
                      <div class=\"price_rating\">
                        <h3>R$$valorproduto,00</h3>
                      </div>
                    </div>
                  </div>
                  </form>
               </div>
";
echo $element;

}

function cartElement($imgproduto,$nomeproduto, $valorproduto, $idproduto){
  $element ="

  <form action  =\"../app/sacola.php?action=remove&id=$idproduto\" method=\"post\" class=\"cart-items\">
                    <div class=\"border rounded\">
                        <div class=\"row bg-white\">
                            <div class=\"col-md-3 pl-0\">
                                <img src=\"../img/perfumes/$imgproduto\" alt=\"Image1\" class=\"img-fluid\">
                            </div>
                            <div class=\"col-md-6\">
                                <h5 class=\"nome\">$nomeproduto</h5>
                                <h5 class=\"valor\">R$$valorproduto</h5>
                                <button type=\"submit\" class=\"remove\" name=\"remove\">Remover</button>
                            </div>
                           
                        </div>
                    </div>
      </form>
    
    ";
    echo $element;
}





?>