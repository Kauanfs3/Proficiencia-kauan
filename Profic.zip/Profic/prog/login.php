<?php

session_start();
require_once '../prog/conexaocad.php';

// Recebe os dados do formulário
$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

if (isset($dados["ENTRAR"])) {
    // echo "<pre>";
    // print_r($dados);
    // echo "</pre>";
    // exit;

    $dados_st = array_map('strip_tags', $dados);
    $dados = array_map('trim', $dados_st);
    // print_r($dados);
    // exit;
    // Verificar se todos os inputs foram preenchidos
    if (in_array('', $dados)) {
        // $empty_input = true;
        $_SESSION['msg'] = '<div class="alert alert-warning d-flex align-items-center" role="alert">
        <div class="fw-bold ms-3">
        Necessário prencher todos os campos!
        </div>
        </div>';
        // echo $_SESSION['msg'];
        // print_r($dados);
        // return $dados;
        // exit;
        header("Location: ../app/index.php");
        exit;
    }

    $sql = "SELECT * FROM usuarios WHERE email =:user  LIMIT 1";
    $result_user = $conn->prepare($sql);
    $result_user->bindParam(':user', $dados['user'], PDO::PARAM_STR);
    $result_user->execute();

    if (($result_user) and ($result_user->rowCount() != 0)) {
        $row_user = $result_user->fetch(PDO::FETCH_ASSOC);
        // echo '<pre>';
        // var_dump($row_user);
        // echo '</pre>';
        // exit;

        $hash = $row_user['senha'];

        if ($dados['senha'] == $hash) {
            $_SESSION['id'] = $row_user['id'];
            $_SESSION['adm'] = $row_user['adm'];
            $_SESSION['nome'] = $row_user['nome'];
            $_SESSION['senha'] = $row_user['senha'];
            $_SESSION['email'] = $row_user['email'];
            $_SESSION['telefone'] = $row_user['telefone'];
            $_SESSION['data_nasc'] = $row_user['data_nasc'];
            $_SESSION['cidade'] = $row_user['cidade'];
            $_SESSION['estado'] = $row_user['estado'];
            $_SESSION['endereco'] = $row_user['endereco'];


            // echo '<pre>';
            // print_r($_SESSION);
            // echo '</pre>';
            // exit;

            // Redireciona para página de perfil

            // var_dump($_SESSION['adm']);
            // exit;
            switch ($_SESSION['adm']) {
                case '0':
                    header("Location: ../app/usuario.php");
                    break;
                case '1':
                    header("Location: ../app/adm.php");
                    break;
                default:
                    header("location: ../app/index.php");
                    break;
            }

            exit;
        } else {
            $_SESSION['msg'] = '<div class="alert alert-warning d-flex align-items-center" role="alert">
                            <div class="fw-bold ms-3">
                                Senha incorreta! Tente novamente ou clique em "Esqueceu a senha?" para redefini-la.
                            </div>
                        </div>';
            // return $dados;
            header("Location: ../app/index.php");
            exit;
        }
    } else {
        $_SESSION['msg'] = '<div class="alert alert-danger d-flex align-items-center" role="alert">
                            <div class="fw-bold ms-3">
                                Usuário ou senha incorretos!
                            </div>
                        </div>';
        // return $dados;
        header("Location: ../app/index.php");
        exit;
    }
}
