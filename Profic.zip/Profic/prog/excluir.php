<?php

include_once 'conexao.php';

$id= $_GET["id"];

$query = "DELETE FROM produtos WHERE id = '$id'";

mysqli_query($conn, $query);

header("location: ../app/adm.php");
exit;