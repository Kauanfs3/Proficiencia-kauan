<?php

//iniciar sessao
session_start();

$_SESSION['pagina'] = basename($_SERVER['PHP_SELF']);

require_once('../prog/conexao.php');
require_once('../prog/componente.php');

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <title>Home</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="../css/index.css" rel="stylesheet">
  <link href="../css/sobre.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

  <!---------------------------------------------------------------CABEÇALHO----------------------------------------->

  <header class="header fixed-top">
    <nav>
      <ul class="marca">
        <li><a href="index.php"><img class="logo" src="../img/logo_final.svg"></a></li>
        <li><a class="nome" href="index.php">ELEMENTARY</a></li>
      </ul>
    </nav>

    <nav>

      <a href="#" id="login"><svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="pessoa bi bi-person-fill" viewBox="0 0 16 16">
          <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
        </svg></a>

      <div class="arrow-up"></div>


      <div class="login">
        <form class="entrar" action="../prog/login.php" method="POST">
          <label class="ent">LOGIN</label>

          <?php
          if (isset($_SESSION['msg'])) {
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
          } ?>

          <input type="email" placeholder="E-mail" name="user">
          <input type="password" placeholder="Senha" name="senha">
          <input type="submit" name="ENTRAR" value="ENTRAR" />

          <div class="help">
            <a href="cadastro.php" class="ajuda">Criar conta</a>
          </div>
        </form>

      </div>

      <div class="comp menu-section">
        <div class="menu-toggle">
          <div class="one"></div>
          <div class="two"></div>
          <div class="three"></div>
        </div>

        <nav class="compac">
          <div class="l-compac">
            <ul>
              <li><a class="#" href="index.php">Home</a></li>
              <li><a href="sobre.php">Sobre nós</a></li>
              <li><a href="faq.php">FAQ</a></li>
            </ul>
          </div>

        </nav>

      </div>
    </nav>
  </header>

  <!---------------------------------------------------------------CABEÇALHO INF----------------------------------------->

  <nav class="cabecalho" id="navbar">
  <div class="links">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a class="pag" href="sobre.php">Sobre nós</a></li>
        <li><a href="faq.php">FAQ</a></li>
      </ul>
    </div>

    <?php
    // SO SE VC NAO TIVER COLOCADO

    if (isset($_SESSION["flash"])) {
      echo $_SESSION["flash"];
      unset($_SESSION["flash"]);
    }
    ?>
  </nav>





  <!---------------------------------------------------------------INICIO----------------------------------------->
  <div class="container-fluid">
    <div class="intro row">
      <div class="col-2">
      </div>

      <div class="texti col-4">
        <h2>SOBRE NÓS</h2>

        <h4>Elementary consiste em transformar a venda de perfumes em compras mais presentes na sociedade, trazendo de forma atualizada a praticidade e sustentabilidade em um único ambiente.
          A marca se desenvolve a partir de estudos e muita dedicação para sempre entregarmos o melhor aos usuários.</h4>
      </div>

      <div class="col-4">
        <div class="qs"></div>
        <img class="qm " src="../img/a1.jpg">
        <div class="qi"></div>
      </div>

      <div class="col-2">
      </div>

    </div>
  </div>




  <div class="meiio container-fluid">
    <div class="meio row">
      <div class="col-2">
      </div>

      <div class="col-4">
        <div class="qs"></div>
        <img class="qm " src="../img/a2.jpg">
        <div class="qi"></div>
      </div>

      <div class="texti col-4">
        <h2>NOSSO OBJETIVO</h2>
        <h4>O objetivo principal é promover o conhecimento sobre nossos produtos e sermos referência na área de perfumes ecológicos. Além de disponibilizarmos uma plataforma moderna e de fácil acesso, onde os usuários poderão usufruir de informações em relação ao lixo de cosméticos gerados no cotidiano.</h4>
        
      </div>

      <div class="col-2">
      </div>

    </div>
  </div>


  <!---------------------------------------------------------------BOTÃO SUBIR AO TOPO----------------------------------------->

  <button class="scrollTop" onclick="backTop()">
    <img src="../img/next.svg" alt="">
  </button>


  <!---------------------------------------------------------------RODAPÉ----------------------------------------->
  <footer class="footer">
    <div class="contfooter">
      <div class="row">

        <div class="footer-col">
          <h4>Suporte</h4>
          <p><a href="../app/index.php">Home</a></p>
          <p><a href="../app/sobre.php">Sobre nós</a></p>
          <p><a href="../app/faq.php">Duvidas Frequentes</a></p>
        </div>

        <div class="footer-col">
          <h4>Contato</h4>
          <p><a href="#">Telefone: (11) 55-91111-1111</a></p>
          <p><a href="#">Email: Elementary@gmail.com</a></p>
        </div>

        <div class="footer-col">
          <h4>Social</h4>
          <div class="social-links">
            
            <a href="https://www.instagram.com/elementary._/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            
          </div>
        </div>
      </div>
    </div>
  </footer>










  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="../js/index.js"></script>


  <script type="text/javascript">
    $(document).ready(function() {
      var arrow = $(".arrow-up");
      var form = $(".login");
      var status = false;
      $("#login").click(function(event) {
        event.preventDefault();
        if (status == false) {
          arrow.fadeIn();
          form.fadeIn();
          status = true;
        } else {
          arrow.fadeOut();
          form.fadeOut();
          status = false;
        }
      })
    })
  </script>

  <script>
    const nextIcon = '<img src="../img/next.svg" class="next" alt:"next">';

    const prevIcon = '<img src="../img/previous.svg" class="prev" alt:"prev">';



    $('.owl-carousel').owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      navText: [
        prevIcon,
        nextIcon
      ],
      responsive: {
        0: {
          items: 1
        },
        400: {
          items: 2
        },
        600: {
          items: 3
        },
        700: {
          items: 3
        },
        900: {
          items: 4
        },
        1000: {
          items: 5
        }
      }
    })
  </script>


  <script>
    // botão subir ao topo//

    window.addEventListener('scroll', function() {
      let scroll = document.querySelector('.scrollTop')
      scroll.classList.toggle('active', window.scrollY > 100)
    })

    function backTop() {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth"
      })
    }
  </script>

  <script>
    $('#ver').on('show.bs.modal', function(event) {
      var button = $(event.relatedTarget)
      var nome = button.data('nome')
      var valor = button.data('valor')
      var img = button.data('img')
      var desc = button.data('desc')
      var modal = $(this)
      modal.find('.modal-nomeproduto').text(nome)
      modal.find('.modal-valorproduto').text(valor)
      modal.find('.modal-desc').text(desc)
      $(".modal-fotoproduto").attr("src", "../img/perfumes/" + img);
    })
  </script>


</body>

</html>