<?php

//iniciar sessao
session_start();

$_SESSION['pagina'] = basename($_SERVER['PHP_SELF']);

require_once('../prog/conexao.php');
require_once('../prog/componente.php');

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <title>Home</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="../css/index.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

  <!---------------------------------------------------------------CABEÇALHO----------------------------------------->

  <header class="header fixed-top">
    <nav>
      <ul class="marca">
        <li><a href="index.php"><img class="logo" src="../img/logo_final.svg"></a></li>
        <li><a class="nome" href="index.php">ELEMENTARY</a></li>
      </ul>
    </nav>

    <nav>

      <a href="#" id="login"><svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="pessoa bi bi-person-fill" viewBox="0 0 16 16">
          <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
        </svg></a>

      <div class="arrow-up"></div>


      <div class="login">
        <form class="entrar" action="../prog/login.php" method="POST">
          <label class="ent">LOGIN</label>

          <?php
          if (isset($_SESSION['msg'])) {
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
          } ?>

          <input type="email" placeholder="E-mail" name="user">
          <input type="password" placeholder="Senha" name="senha">
          <input type="submit" name="ENTRAR" value="ENTRAR" />

          <div class="help">
            <a href="cadastro.php" class="ajuda">Criar conta</a>
          </div>
        </form>

      </div>

      <div class="comp menu-section">
        <div class="menu-toggle">
          <div class="one"></div>
          <div class="two"></div>
          <div class="three"></div>
        </div>

        <nav class="compac">
          <div class="l-compac">
            <ul>
              <li><a class="#" href="index.php">Home</a></li>
              <li><a href="sobre.php">Sobre nós</a></li>
              <li><a href="faq.php">FAQ</a></li>
            </ul>
          </div>

        </nav>

      </div>
    </nav>
  </header>

  <!---------------------------------------------------------------CABEÇALHO INF----------------------------------------->

  <nav class="cabecalho" id="navbar">
    <div class="links">
      <ul>
        <li><a class="pag" href="index.php">Home</a></li>
        <li><a href="sobre.php">Sobre nós</a></li>
        <li><a href="faq.php">FAQ</a></li>
      </ul>
    </div>

    <?php

    // SO SE VC NAO TIVER COLOCADO

    if (isset($_SESSION["flash"])) {
      echo $_SESSION["flash"];
      unset($_SESSION["flash"]);
    }
    ?>

  </nav>





  <!---------------------------------------------------------------INICIO----------------------------------------->
  <div class="container-fluid">
    <div class="intro row">
      <div class="col-2">
      </div>

      <div class="texti col-4">
        <h2>PROMOÇÃO DA SEMANA</h2>

        <h4>Venha conferir as promoções que preparamos para você!!</h4>
      </div>

      <div class="col-4">
        <div class="qs"></div>
        <img class="qm " src="../img/propaganda.jpg">
        <div class="qi"></div>
      </div>

      <div class="col-2">
      </div>

    </div>
  </div>


  <!---------------------------------------------------------------MODAL - aviso----------------------------------------->
  <div class="base modal fade" id="aviso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="area modal-dialog modal-dialog-centered">
      <div class="caca modal-content">

        <div class="caixinha modal-header">
          <h3 class="titull">Aviso</h3>

          <button type="button" class="sair-a btn" data-dismiss="modal"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
              <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
            </svg>
          </button>
        </div>


        <div class="modal-body">
          <div class="conteudo row">
            <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="erro bi bi-exclamation-triangle-fill" viewBox="0 0 16 16">
              <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
            </svg>

            <div class="borda-a"></div>

            <form class="info">
              <p class="aviso">Para adicionar itens a sacola é nescessário estar cadastrado!</hp>

            </form>
          </div>
        </div>
      </div>

    </div>
  </div>
  </div>



  <!---------------------------------------------------------------MODAL - informações----------------------------------------->
  <div class="base modal fade" id="ver" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="area modal-dialog modal-dialog-centered modal-lg">
      <div class="caca modal-content">

        <div class="caixinha modal-header">
          <h3 class="titul">DADOS DO PRODUTO</h3>

          <button type="button" class="sair btn" data-dismiss="modal"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
              <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
            </svg>
          </button>
        </div>


        <div class="modal-body">
          <div class="row">
            <div class="col-6">
              <img class="modal-fotoproduto foto" alt="App Logo">
            </div>


            <div class="borda"></div>

            <div class="textos col-6">
              <form class="info">
                <p class="tit">Produto</p>
                <div class="inf">
                  <span class="add-on"></span> <span class="modal-nomeproduto"></span>
                </div>

                <p class="tit">Valor</p>
                <div class="inf">
                  <span class="add-on"></span>R$<span class="modal-valorproduto"></span>,00
                </div>

                <p class="tit">Descrição</p>
                <div class="inf">
                  <span class="add-on"></span><span class="modal-desc"></span>
                </div>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>








  <!---------------------------------------------------------------LINHA 1----------------------------------------->
  <div class="titulo container-fluid">
    <h1 class="ti">PROMOÇÕES</h1>
  </div>

  <div class="container">

    <!--slide box-->
    <div class="row">
      <div class="owl-carousel owl-theme">

        <?php
        //component("produto 1",  "R$599,00", "../img/p1.jpg");


        $result = $conexao->getDataPromocao();

        while ($row = mysqli_fetch_assoc($result)) {
          component($row['nome_produto'], $row['valor_produto'], $row['img_produto'], $row['id'], $row['descricao']);
        }

        ?>


      </div>


    </div>

  </div>




  <!---------------------------------------------------------------LINHA 2----------------------------------------->
  <div class="titulo container-fluid">
    <h1 class="ti">PERFUMES</h1>
  </div>

  <div class="container">

    <!--slide box-->
    <div class="row">
      <div class="owl-carousel owl-theme">

        <?php

        $result = $conexao->getDataNovidades();

        while ($row = mysqli_fetch_assoc($result)) {
          component($row['nome_produto'], $row['valor_produto'], $row['img_produto'], $row['id'], $row['descricao']);
        }

        ?>

      </div>
    </div>

  </div>





  <!---------------------------------------------------------------QUEM SOMOS----------------------------------------->
  <div class="meiio titulo container-fluid">
  </div>

  <div class="meiio container-fluid">
    <div class="meio row">
      <div class="col-2">
      </div>

      <div class="col-4">
        <div class="qs"></div>
        <img class="qm " src="../img/propaganda.jpg">
        <div class="qi"></div>
      </div>

      <div class="texti col-4">
        <h2>SOBRE NÓS</h2>
        <h4>Elementary  busca transformar a venda de perfumes mais presente na sociedade, de forma atualizada, prática e sustentável em um único ambiente.</h4>
        <a href="../app/sobre.php">Veja aqui</a>
      </div>

      <div class="col-2">
      </div>

    </div>
  </div>


  <!---------------------------------------------------------------LINHA 3----------------------------------------->
  <div class="titulo container-fluid">
    <h1 class="ti">REFILS</h1>
  </div>

  <div class="container">

    <!--slide box-->
    <div class="row">
      <div class="owl-carousel owl-theme">

        <?php
        $result = $conexao->getDataRefils();

        while ($row = mysqli_fetch_assoc($result)) {
          component($row['nome_produto'], $row['valor_produto'], $row['img_produto'], $row['id'], $row['descricao']);
        }

        ?>

      </div>
    </div>

  </div>

  <!---------------------------------------------------------------LINHA 4----------------------------------------->
  <div class="titulo container-fluid">
    <h1 class="ti">KITS</h1>
  </div>

  <div class="container">

    <!--slide box-->
    <div class="row">
      <div class="owl-carousel owl-theme">

        <?php
        $result = $conexao->getDataKits();

        while ($row = mysqli_fetch_assoc($result)) {
          component($row['nome_produto'], $row['valor_produto'], $row['img_produto'], $row['id'], $row['descricao']);
        }

        ?>

      </div>
    </div>

  </div>


  <!---------------------------------------------------------------BOTÃO SUBIR AO TOPO----------------------------------------->

  <button class="scrollTop" onclick="backTop()">
    <img src="../img/next.svg" alt="">
  </button>


  <!---------------------------------------------------------------RODAPÉ----------------------------------------->
  <footer class="footer">
    <div class="contfooter">
      <div class="row">

        <div class="footer-col">
          <h4>Suporte</h4>
          <p><a href="../app/sobre.php">Sobre nós</a></p>
          <p><a href="../app/faq.php">Duvidas Frequentes</a></p>
        </div>

        <div class="footer-col">
          <h4>Contato</h4>
          <p><a href="#">Telefone: (11) 55-91111-1111</a></p>
          <p><a href="#">Email: Elementary@gmail.com</a></p>
        </div>

        <div class="footer-col">
          <h4>Social</h4>
          <div class="social-links">
            
            <a href="https://www.instagram.com/elementary._/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            
          </div>
        </div>
      </div>
    </div>
  </footer>










  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="../js/index.js"></script>


  <script type="text/javascript">
    $(document).ready(function() {
      var arrow = $(".arrow-up");
      var form = $(".login");
      var status = false;
      $("#login").click(function(event) {
        event.preventDefault();
        if (status == false) {
          arrow.fadeIn();
          form.fadeIn();
          status = true;
        } else {
          arrow.fadeOut();
          form.fadeOut();
          status = false;
        }
      })
    })
  </script>

  <script>
    const nextIcon = '<img src="../img/next.svg" class="next" alt:"next">';

    const prevIcon = '<img src="../img/previous.svg" class="prev" alt:"prev">';



    $('.owl-carousel').owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      navText: [
        prevIcon,
        nextIcon
      ],
      responsive: {
        0: {
          items: 1
        },
        400: {
          items: 2
        },
        600: {
          items: 3
        },
        700: {
          items: 3
        },
        900: {
          items: 4
        },
        1000: {
          items: 5
        }
      }
    })
  </script>


  <script>
    // botão subir ao topo//

    window.addEventListener('scroll', function() {
      let scroll = document.querySelector('.scrollTop')
      scroll.classList.toggle('active', window.scrollY > 100)
    })

    function backTop() {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth"
      })
    }
  </script>

  <script>
    $('#ver').on('show.bs.modal', function(event) {
      var button = $(event.relatedTarget)
      var nome = button.data('nome')
      var valor = button.data('valor')
      var img = button.data('img')
      var desc = button.data('desc')
      var modal = $(this)
      modal.find('.modal-nomeproduto').text(nome)
      modal.find('.modal-valorproduto').text(valor)
      modal.find('.modal-desc').text(desc)
      $(".modal-fotoproduto").attr("src", "../img/perfumes/" + img);
    })
  </script>





</body>

</html>