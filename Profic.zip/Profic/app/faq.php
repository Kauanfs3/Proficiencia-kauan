<?php

//iniciar sessao
session_start();

$_SESSION['pagina'] = basename($_SERVER['PHP_SELF']);

require_once('../prog/conexao.php');
require_once('../prog/componente.php');

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <title>Home</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="../css/index.css" rel="stylesheet">
  <link href="../css/faq.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

  <!---------------------------------------------------------------CABEÇALHO----------------------------------------->

  <header class="header fixed-top">
    <nav>
      <ul class="marca">
        <li><a href="index.php"><img class="logo" src="../img/logo_final.svg"></a></li>
        <li><a class="nome" href="index.php">ELEMENTARY</a></li>
      </ul>
    </nav>

    <nav>

      <a href="#" id="login"><svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="pessoa bi bi-person-fill" viewBox="0 0 16 16">
          <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
        </svg></a>

      <div class="arrow-up"></div>


      <div class="login">
        <form class="entrar" action="../prog/login.php" method="POST">
          <label class="ent">LOGIN</label>

          <?php
          if (isset($_SESSION['msg'])) {
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
          } ?>

          <input type="email" placeholder="E-mail" name="user">
          <input type="password" placeholder="Senha" name="senha">
          <input type="submit" name="ENTRAR" value="ENTRAR" />

          <div class="help">
            <a href="cadastro.php" class="ajuda">Criar conta</a>
          </div>
        </form>

      </div>

      <div class="comp menu-section">
        <div class="menu-toggle">
          <div class="one"></div>
          <div class="two"></div>
          <div class="three"></div>
        </div>

        <nav class="compac">
          <div class="l-compac">
            <ul>
              <li><a class="#" href="index.php">Home</a></li>
              <li><a href="sobre.php">Sobre nós</a></li>
              <li><a href="faq.php">FAQ</a></li>
            </ul>
          </div>

        </nav>

      </div>
    </nav>
  </header>

  <!---------------------------------------------------------------CABEÇALHO INF----------------------------------------->

  <nav class="cabecalho" id="navbar">
  <div class="links">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="sobre.php">Sobre nós</a></li>
        <li><a class="pag" href="faq.php">FAQ</a></li>
      </ul>
    </div>

    <?php
    // SO SE VC NAO TIVER COLOCADO

    if (isset($_SESSION["flash"])) {
      echo $_SESSION["flash"];
      unset($_SESSION["flash"]);
    }
    ?>

  </nav>





  <!---------------------------------------------------------------INICIO----------------------------------------->
  <div class="container-fluid">
    <div class="faq row">
      <div class="col-2">
      </div>





      <div class="col-8">
        <div class="caixa accordion" id="accordionExample">


          <div class="card">
            <button id="topico" class="btn" type="button" data-toggle="collapse" data-target="#collapse1" aria-controls="collapse1">
              Como me cadastrar?
            </button>

            <div id="collapse1" class="collapse" aria-labelledby="heading1" data-parent="#accordionExample">
              <div class="card-body">
                <p> Para realizar seu cadastro passe o mouse em cima da opção "Login", no topo do site. Em seguida, clique em "Criar Conta" e insira os seus dados pessoais, depois clique em ´Próximo´. Digite os dados solicitados e finalize o cadastro. </p>
                <p> Pronto! Você já terá seu cadastro finalizado para poder efetuar compras no site.</p>
              </div>
            </div>
          </div>


          <div class="card">
            <button id="topico" class="btn" type="button" data-toggle="collapse" data-target="#collapse2" aria-controls="collapse2">
              Como posso entrar em contato?
            </button>

            <div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#accordionExample">
              <div class="card-body">
                <p> Você pode entrar em contato conosco através do e-mail atendimento@elementay.com.br.</p>
                <p> O prazo para resposta é de até 2 (dois) dias úteis</p>
              </div>
            </div>
          </div>


          <div class="card">
            <button id="topico" class="btn" type="button" data-toggle="collapse" data-target="#collapse3" aria-controls="collapse3">
              Devoluções/trocas de embalagens
            </button>

            <div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#accordionExample">
              <div class="card-body">
                <p>Para fazer a troca, os consumidores precisam se cadastrar no site (.com.br) e, depois, entregar a embalagem vazia em uma loja.</p>
                <p>Ao fazer o cadastro, o participante recebe a confirmação do cupom via email, referente a troca, e verifica a disponibilidade dos produtos.</p>
              </div>
            </div>
          </div>

          <div class="card">
            <button id="topico" class="btn" type="button" data-toggle="collapse" data-target="#collapse4" aria-controls="collapse4">
              Tem valor mínimo para compra?
            </button>

            <div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#accordionExample">
              <div class="card-body">
                Não tem valor mínimo para compra.
              </div>
            </div>
          </div>




        </div>
      </div>





      <div class="col-2">
      </div>

    </div>
  </div>






  <!---------------------------------------------------------------RODAPÉ----------------------------------------->
  <footer class="footer">
    <div class="contfooter">
      <div class="row">

        <div class="footer-col">
          <h4>Suporte</h4>
          <p><a href="../app/index.php">Home</a></p>
          <p><a href="../app/sobre.php">Sobre nós</a></p>
          <p><a href="../app/faq.php">Duvidas Frequentes</a></p>
        </div>

        <div class="footer-col">
          <h4>Contato</h4>
          <p><a href="#">Telefone: (11) 55-91111-1111</a></p>
          <p><a href="#">Email: Elementary@gmail.com</a></p>
        </div>

        <div class="footer-col">
          <h4>Social</h4>
          <div class="social-links">
            
            <a href="https://www.instagram.com/elementary._/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            
          </div>
        </div>
      </div>
    </div>
  </footer>










  <script src="../js/index.js"></script>




</body>

</html>