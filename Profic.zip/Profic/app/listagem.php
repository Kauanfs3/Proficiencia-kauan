<?php

session_start();

require_once('../prog/conexaocad.php');

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <title>Lista usuarios</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="../css/index.css" rel="stylesheet">
  <link href="../css/listagem.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

  <!---------------------------------------------------------------CABEÇALHO----------------------------------------->

  <header class="header fixed-top">
    <nav>
      <ul class="marca">
        <li><a href="index.php"><img class="logo" src="../img/logo_final.svg"></a></li>
        <li><a class="nome" href="index.php">ELEMENTARY</a></li>
      </ul>
    </nav>

    <nav>

      <a href="../app/adm.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-door-fill" viewBox="0 0 16 16">
          <path d="M6.5 14.5v-3.505c0-.245.25-.495.5-.495h2c.25 0 .5.25.5.5v3.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5z" />
      </svg></a>

      <div class="comp menu-section">
        <div class="menu-toggle">
          <div class="one"></div>
          <div class="two"></div>
          <div class="three"></div>
        </div>

        <nav class="compac">
          <div class="l-compac">
            <ul>
              <li><a class="#" href="index.php">Home</a></li>
              <li><a href="sobre.php">Sobre nós</a></li>
              <li><a href="faq.php">FAQ</a></li>
            </ul>
          </div>

        </nav>

      </div>
    </nav>
  </header>

  <!---------------------------------------------------------------CABEÇALHO INF----------------------------------------->

  <nav class="cabecalho" id="navbar">
    <div class="links">
      <ul>
        <li><a class="pag" href="index.php">Home</a></li>
        <li><a href="sobre.php">Sobre nós</a></li>
        <li><a href="faq.php">FAQ</a></li>
      </ul>
    </div>

    <?php
    // SO SE VC NAO TIVER COLOCADO

    if (isset($_SESSION["flash"])) {
      echo $_SESSION["flash"];
      unset($_SESSION["flash"]);
    }
    ?>


  </nav>





  <!---------------------------------------------------------------INICIO----------------------------------------->
  <div class="container-fluid">
    <div class="lista row">
      <div class="col-1">
      </div>





      <div class="col-10">

        <table class="table">
          <thead>
            <tr>
              <th cope="col">Nome</th>
              <th cope="col">Email</th>
              <th cope="col">Telefone</th>
              <th cope="col">Data de nascimento</th>
              <th cope="col">Cidade</th>
              <th cope="col">Estado</th>
              <th cope="col">Endereco</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $query = $conn->prepare("SELECT * FROM usuarios");
            $query->execute();
            $usuarios = $query->fetchAll();

            foreach ($usuarios as $usuario) {
            ?>
              <tr scope="row">
                <td><?= $usuario["nome"] ?></td>
                <td><?= $usuario["email"] ?></td>
                <td><?= $usuario["telefone"] ?></td>
                <td><?= $usuario["data_nasc"] ?></td>
                <td><?= $usuario["cidade"] ?></td>
                <td><?= $usuario["estado"] ?></td>
                <td><?= $usuario["endereco"] ?></td>
              </tr>

            <?php
            }
            ?>
          </tbody>


        </table>
      </div>





      <div class="col-1">
      </div>

    </div>
  </div>






  <!---------------------------------------------------------------RODAPÉ----------------------------------------->
  <footer class="footer">
    <div class="contfooter">
      <div class="row">

          <div class="footer-col">
          <h4>Suporte</h4>
          <p><a href="../app/index.php">Home</a></p>
          <p><a href="../app/sobre.php">Sobre nós</a></p>
          <p><a href="../app/faq.php">Duvidas Frequentes</a></p>
        </div>

        <div class="footer-col">
          <h4>Contato</h4>
          <p><a href="#">Telefone: (11) 55-91111-1111</a></p>
          <p><a href="#">Email: Elementary@gmail.com</a></p>
        </div>

        <div class="footer-col">
          <h4>Social</h4>
          <div class="social-links">
            <a href="https://www.instagram.com/elementary._/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
          </div>
        </div>
      </div>
    </div>
  </footer>










  <script src="../js/index.js"></script>




</body>

</html>


<!-- <div class="usuario">
            <p><?= $usuario["nome"] ?></p>
            <p><?= $usuario["email"] ?></p>
            <p><?= $usuario["telefone"] ?></p>
            <p><?= $usuario["data_nasc"] ?></p>
            <p><?= $usuario["cidade"] ?></p>
            <p><?= $usuario["estado"] ?></p>
            <p><?= $usuario["endereco"] ?></p>
        </div> -->