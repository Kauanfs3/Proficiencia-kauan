<?php

//iniciar sessao
session_start();

$_SESSION['pagina'] = basename($_SERVER['PHP_SELF']);

require_once('../prog/conexao.php');
require_once('../prog/componenteUsuario.php');


if (!session_id()) {
  session_start();
}

if (!isset($_SESSION["nome"]) && !isset($_SESSION["senha"])) {
  header("Location: index.php");
  exit;
}

$logado = $_SESSION['nome'];



//prog CARRINHO

if (isset($_POST['add'])) {
  //print_r ($_POST['id_produto']);   printar id

  if (isset($_SESSION['cart'])) {

    $item_array_id = array_column($_SESSION['cart'], "id_produto");

    if (in_array($_POST['id_produto'], $item_array_id)) {
      echo "<script>alert('O produto já está adicionado ao carrinho ..!')</script>";
      echo "<script> window.location='index.php</script>";
    } else {
      $count = count($_SESSION['cart']);
      $item_array = array(
        'id_produto' => $_POST['id_produto']
      );

      $_SESSION['cart'][$count] = $item_array;
      print_r($_SESSION['cart']);
    }
  } else {

    $item_array = array(
      'id_produto' => $_POST['id_produto']
    );

    //criar nova sessao variavel
    $_SESSION['cart'][0] = $item_array;
    print_r($_SESSION['cart']);
  }
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <title>Home</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="../css/index.css" rel="stylesheet">
  <link href="../css/usuario.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

  <!---------------------------------------------------------------CABEÇALHO----------------------------------------->

  <header class="header fixed-top">
    <nav>
      <ul class="marca">
        <li><a href="usuario.php"><img class="logo" src="../img/logo_final.svg"></a></li>
        <li><a class="nome" href="usuario.php">ELEMENTARY</a></li>
      </ul>
    </nav>

    <nav>



      <!-- PERFIL -->
      <a href="#" id="login"><svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="pessoa bi bi-person-fill" viewBox="0 0 16 16">
          <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
        </svg></a>

      <div class="arrow-up"></div>

      <div class="login">
        <p class="ent"><?php echo "<h5>Bem vinde $logado</h5>"; ?></p>

        <div class="perfil">
          <a type="button" class="opcao" data-toggle="modal" data-target="#editar">Editar perfil</a>
        </div>

        <div class="perfil">
          <a class="opcao" href="../prog/sair.php">Desconectar</a>
        </div>

      </div>

      <a href="sacola.php">
        <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="sacola bi bi-bag-fill" viewBox="0 0 16 16">
          <path d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5z" />
        </svg>

        <h4>
          <?php
          if (isset($_SESSION['cart'])) {
            $count = count($_SESSION['cart']);

            echo "<span id=\"cart_count\" class=\"contador\">$count</span>";
          } else {
            echo "<span id=\"cart_count\" class=\"contador\">0</span>";
          }
          ?>
        </h4>
      </a>



      <section class="fundo"></section>

      <div class="comp menu-section">
        <div class="menu-toggle">
          <div class="one"></div>
          <div class="two"></div>
          <div class="three"></div>
        </div>

        <nav class="compac">
        <div class="l-compac">
            <ul>
              <li><a class="#" href="usuario.php">Home</a></li>
              <li><a href="sobre.php">Sobre nós</a></li>
              <li><a href="faq.php">FAQ</a></li>
            </ul>
          </div>

        </nav>

      </div>
    </nav>
  </header>

  <!---------------------------------------------------------------CABEÇALHO INF----------------------------------------->

  <nav class="cabecalho" id="navbar">
     <div class="links">
      <ul>
        <li><a class="pag" href="usuario.php">Home</a></li>
        <li><a href="sobre.php">Sobre nós</a></li>
        <li><a href="faq.php">FAQ</a></li>
      </ul>
    </div>


  </nav>





  <!---------------------------------------------------------------INICIO----------------------------------------->
  <div class="container-fluid">
    <div class="intro row">
      <div class="col-2">
      </div>

      <div class="texti col-4">
        <h2>PROMOÇÃO DA SEMANA</h2>

        <h4>Venha conferir as promoções que preparamos para você!!</h4>
      </div>



      <div class="col-4">
        <div class="qs"></div>
        <img class="qm" src="../img/propaganda.jpg">
        <div class="qi"></div>
      </div>

      <div class="col-2">
      </div>

    </div>
  </div>




  <!---------------------------------------------------------------MODAL - informações----------------------------------------->
  <div class="base modal fade" id="ver" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="area modal-dialog modal-dialog-centered modal-lg">
      <div class="caca modal-content">

        <div class="caixinha modal-header">
          <h3 class="titul">DADOS DO PRODUTO</h3>

          <button type="button" class="sair btn" data-dismiss="modal"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
              <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
            </svg>
          </button>
        </div>


        <div class="modal-body">
          <div class="row">
            <div class="col-6">
              <img class="modal-fotoproduto foto" alt="App Logo">
            </div>


            <div class="borda"></div>

            <div class="textos col-6">
              <form class="info">
                <p class="tit">Produto</p>
                <div class="inf">
                  <span class="add-on"></span> <span class="modal-nomeproduto"></span>
                </div>

                <p class="tit">Valor</p>
                <div class="inf">
                  <span class="add-on"></span>R$<span class="modal-valorproduto"></span>,00
                </div>

                <p class="tit">Descrição</p>
                <div class="inf">
                  <span class="add-on"></span><span class="modal-desc"></span>
                </div>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>



  <!---------------------------------------------------------------MODAL - editar perfil----------------------------------------->

  <div class="base modal fade" id="editar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="area modal-dialog modal-dialog-centered modal-lg">
      <div class="caca modal-content">

        <div class="caixinha modal-header">
          <h3 class="titul">EDITAR PERFIL</h3>

          <button type="button" class="sair-e btn" data-dismiss="modal"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
              <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
            </svg>
          </button>
        </div>


        <div class="corpo modal-body">
          <div class="row">
            <div class="borda-p"></div>

            <div class="col-5">
              <form class="info" method="POST" action="#">

                <p class="ti">Nome</p>
                <div class="inf">
                  <span class="add-on"></span><input class="prependedInput" type="text" value='<?= $_SESSION['nome'] ?>' name="nome">
                </div>

                <p class="ti">Email</p>
                <div class="inf">
                  <span class="add-on"></span><input class="prependedInput" type="text" value='<?= $_SESSION['email'] ?>' name="email">
                </div>

                <p class="ti">Senha</p>
                <div class="inf">
                  <span class="add-on"></span><input class="prependedInput" type="text" value='<?= $_SESSION['senha'] ?>' name="senha">
                </div>

                <p class="ti">Telefone</p>
                <div class="inf">
                  <span class="add-on"></span><input class="prependedInput" type="text" value='<?= $_SESSION['telefone'] ?>' name="telefone">
                </div>
            </div>


            <div class="corpo col-5 offset-2">
              <p class="ti">Data de nascimento</p>
              <div class="inf">
                <span class="add-on"></span><input class="prependedInput" type="text" value='<?= $_SESSION['data_nasc'] ?>' name="data_nasc">
              </div>


              <p class="ti">Cidade</p>
              <div class="inf">
                <span class="add-on"></span><input class="prependedInput" type="text" value='<?= $_SESSION['cidade'] ?>' name="cidade">
              </div>

              <p class="ti">Estado</p>
              <div class="inf">
                <span class="add-on"></span><input class="prependedInput" type="text" value='<?= $_SESSION['estado'] ?>' name="estado">
              </div>

              <p class="ti">Endereço</p>
              <div class="inf">
                <span class="add-on"></span><input class="prependedInput" type="text" value='<?= $_SESSION['endereco'] ?>' name="endereco">
              </div>

              <button type="submit" class="btn" name="enviar">EDITAR</button>
              </form>
            </div>








            <?php
            if (isset($_POST["enviar"])) {

              $nome = $_POST["nome"];
              $email = $_POST["email"];
              $senha = $_POST["senha"];
              $telefone = $_POST["telefone"];
              $data_nasc = $_POST["data_nasc"];
              $estado = $_POST["estado"];
              $cidade = $_POST["cidade"];
              $endereco = $_POST["endereco"];

              $_SESSION['nome'] = $nome;
              $_SESSION['senha'] = $senha;
              $_SESSION['email'] = $email;
              $_SESSION['telefone'] = $telefone;
              $_SESSION['data_nasc'] = $data_nasc;
              $_SESSION['cidade'] = $cidade;
              $_SESSION['estado'] = $estado;
              $_SESSION['endereco'] = $endereco;

              $query = $conn->prepare("UPDATE usuarios SET
                nome = '$nome',
                email = '$email',
                senha = '$senha',
                telefone = '$telefone',
                data_nasc = '$data_nasc',
                estado = '$estado',
                cidade = '$cidade',
                endereco = '$endereco'
                WHERE id = " . $_SESSION["id"]);

              $query->execute();
            }


            ?>
          </div>
        </div>
      </div>

    </div>
  </div>


  <!---------------------------------------------------------------LINHA 1----------------------------------------->
  <div class="titulo container-fluid">
    <h1 class="ti">Promoções</h1>
  </div>

  <div class="container">

    <!--slide box-->
    <div class="row">
      <div class="owl-carousel owl-theme">

        <?php
        //component("produto 1",  "R$599,00", "../img/p1.jpg");


        $result = $conexao->getDataPromocao();

        while ($row = mysqli_fetch_assoc($result)) {
          component($row['nome_produto'], $row['valor_produto'], $row['img_produto'], $row['id'], $row['descricao'], $row['categoria']);
        }

        ?>


      </div>


    </div>

  </div>




  <!---------------------------------------------------------------LINHA 2----------------------------------------->
  <div class="titulo container-fluid">
    <h1 class="ti">Perfumes</h1>
  </div>

  <div class="container">

    <!--slide box-->
    <div class="row">
      <div class="owl-carousel owl-theme">

        <?php

        $result = $conexao->getDataNovidades();

        while ($row = mysqli_fetch_assoc($result)) {
          component($row['nome_produto'], $row['valor_produto'], $row['img_produto'], $row['id'], $row['descricao'], $row['categoria']);
        }

        ?>

      </div>
    </div>

  </div>





  <!---------------------------------------------------------------QUEM SOMOS----------------------------------------->
  <div class="meiio titulo container-fluid">
  </div>

  <div class="meiio container-fluid">
    <div class="meio row">
      <div class="col-2">
      </div>

      <div class="col-4">
        <div class="qs"></div>
        <img class="qm " src="../img/propaganda.jpg">
        <div class="qi"></div>
      </div>

      <div class="texti col-4">
        <h2>SOBRE NÓS</h2>
        <h4>Elementary busca transformar a venda de perfumes mais presente na sociedade, de forma atualizada, prática e sustentável em um único ambiente</h4>
        <a href="../app/sobre.php">Veja aqui</a>
      </div>

      <div class="col-2">
      </div>

    </div>
  </div>


  <!---------------------------------------------------------------LINHA 3----------------------------------------->
  <div class="titulo container-fluid">
    <h1 class="ti">Refils</h1>
  </div>

  <div class="container">

    <!--slide box-->
    <div class="row">
      <div class="owl-carousel owl-theme">

        <?php
        $result = $conexao->getDataRefils();

        while ($row = mysqli_fetch_assoc($result)) {
          component($row['nome_produto'], $row['valor_produto'], $row['img_produto'], $row['id'], $row['descricao'], $row['categoria']);
        }

        ?>

      </div>
    </div>

  </div>

  <!---------------------------------------------------------------LINHA 4----------------------------------------->
  <div class="titulo container-fluid">
    <h1 class="ti">Kits</h1>
  </div>

  <div class="container">

    <!--slide box-->
    <div class="row">
      <div class="owl-carousel owl-theme">

        <?php
        $result = $conexao->getDataKits();

        while ($row = mysqli_fetch_assoc($result)) {
          component($row['nome_produto'], $row['valor_produto'], $row['img_produto'], $row['id'], $row['descricao'], $row['categoria']);
        }

        ?>

      </div>
    </div>

  </div>


  <!---------------------------------------------------------------BOTÃO SUBIR AO TOPO----------------------------------------->

  <button class="scrollTop" onclick="backTop()">
    <img src="../img/next.svg" alt="">
  </button>


  <!---------------------------------------------------------------RODAPÉ--------------------- -------------------->
  <footer class="footer">
    <div class="contfooter">
      <div class="row">

        <div class="footer-col">
          <h4>Suporte</h4>
          <p><a href="../app/sobre.php">Sobre nós</a></p>
          <p><a href="../app/faq.php">Duvidas Frequentes</a></p>
        </div>

        <div class="footer-col">
          <h4>Contato</h4>
          <p><a href="#">Telefone: (11) 55-91111-1111</a></p>
          <p><a href="#">Email: Elementary@gmail.com</a></p>
        </div>

        <div class="footer-col">
          <h4>Social</h4>
          <div class="social-links">
            <a href="https://www.instagram.com/elementary._/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
          </div>
        </div>
      </div>
    </div>
  </footer>










  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="../js/index.js"></script>


  <script type="text/javascript">
    $(document).ready(function() {
      var arrow = $(".arrow-up");
      var form = $(".login");
      var status = false;
      $("#login").click(function(event) {
        event.preventDefault();
        if (status == false) {
          arrow.fadeIn();
          form.fadeIn();
          status = true;
        } else {
          arrow.fadeOut();
          form.fadeOut();
          status = false;
        }
      })
    })
  </script>

  <script>
    const nextIcon = '<img src="../img/next.svg" class="next" alt:"next">';

    const prevIcon = '<img src="../img/previous.svg" class="prev" alt:"prev">';



    $('.owl-carousel').owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      navText: [
        prevIcon,
        nextIcon
      ],
      responsive: {
        0: {
          items: 1
        },
        400: {
          items: 2
        },
        600: {
          items: 3
        },
        700: {
          items: 3
        },
        900: {
          items: 4
        },
        1000: {
          items: 5
        }
      }
    })
  </script>


  <script>
    // botão subir ao topo//

    window.addEventListener('scroll', function() {
      let scroll = document.querySelector('.scrollTop')
      scroll.classList.toggle('active', window.scrollY > 100)
    })

    function backTop() {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth"
      })
    }
  </script>

  <script>
    $('#ver').on('show.bs.modal', function(event) {
      var button = $(event.relatedTarget)
      var nome = button.data('nome')
      var valor = button.data('valor')
      var img = button.data('img')
      var desc = button.data('desc')
      var modal = $(this)
      modal.find('.modal-nomeproduto').text(nome)
      modal.find('.modal-valorproduto').text(valor)
      modal.find('.modal-desc').text(desc)
      $(".modal-fotoproduto").attr("src", "../img/perfumes/" + img);
    })
  </script>


</body>

</html>