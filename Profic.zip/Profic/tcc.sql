-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28-Ago-2022 às 02:01
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tcc`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `nome_produto` varchar(25) DEFAULT NULL,
  `valor_produto` float NOT NULL,
  `img_produto` varchar(100) NOT NULL,
  `categoria` varchar(20) NOT NULL,
  `descricao` varchar(200) NOT NULL,
  `aroma` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome_produto`, `valor_produto`, `img_produto`, `categoria`, `descricao`, `aroma`) VALUES
(1, 'FLORA', 89, 'COFFE.jpg', 'promocao', 'Kit Presente de Natal Red (2 itens)', 'aromatico'),
(2, 'MALBEC', 123, 'florata.jpg', 'promocao', 'Kit Desodorante Colônia 50ml + Desodorante Antitranspirante Aerossol 31g + Sabonete Líquido Corporal 75ml', 'amadeirado'),
(3, 'MALBEC MINI', 224, 'kkk3.jpg', 'kits', 'Kit Presente Malbec: Desodorante Colônia 100ml + Loção Corporal 250ml + Sabonete Líquido Corporal 250ml', 'citrico'),
(4, 'MEN', 324, 'kk5.jpg', 'kits', 'Combo Bomb: Bomb Black 90ml + Bomb Purple 90ml', 'frutal'),
(6, 'MALBEC', 312, 'kk4.jpg', 'kits', 'Secrets Black Desodorante Colônia 75ml', 'oriental'),
(7, 'INTENSE', 239, 'kk1.jpg', 'kits', 'Secrets Black Desodorante Colônia 75ml', 'floral'),
(9, 'REFIL LIMAO', 25, 'r3.jpg', 'refils', 'Secrets Black Desodorante Colônia 75ml', 'frutal'),
(11, 'REFIL BAUNILHA', 25, 'r1.jpg', 're', 'Secrets Black Desodorante Colônia 75ml', 'floral'),
(13, 'EGEO', 200, 'k2.jpg', 'kits', 'Secrets Black Desodorante Colônia 75ml', 'floral'),
(14, 'INTENSE', 150, 'k3.jpg', 'kits', 'Secrets Black Desodorante Colônia 75ml', 'floral'),
(15, 'LIZ', 244, 'k4.jpg', 'kits', 'Secrets Black Desodorante Colônia 75ml', 'floral'),
(16, 'LILY', 376, 'k5.jpg', 'kits', 'Secrets Black Desodorante Colônia 75ml', 'aromatico'),
(17, 'PARIS', 356, 'k6.jpg', 'kits', 'Secrets Black Desodorante Colônia 75ml', 'aromatico'),
(19, 'GLAMOUR', 150, '18.jpg', 'novidades', 'Secrets Black Desodorante Colônia 75ml', 'floral'),
(48, 'EGOISTE', 345, '15.jpg', 'promocao', 'Body Splash Desodorante Colônia Cuide-se Bem Boa Noite 200ml', 'oriental'),
(50, 'ELYSÉ', 432, '16.jpg', 'novidades', 'Splash Desodorante Colônia Cardamom 200ml', 'floral'),
(51, 'INTENSE', 234, '19.jpg', 'novidades', 'Splash Desodorante Colônia Cardamom 200ml', 'floral'),
(52, 'BELLE', 213, 'La_vie_belle_Lancôme.jpg', 'novidades', 'floral', ''),
(53, 'MALBEC', 124, 'malbec.jpg', 'novidades', 'Splash Desodorante Colônia Cardamom 200ml', 'oriental'),
(55, 'BLEU', 321, '1638851281.jpg', 'novidades', 'Splash Desodorante Colônia Cardamom 200ml', 'frutal'),
(56, 'BLUUE', 500, 'n4.jpg', 'novidades', 'Splash Desodorante Colônia Cardamom 200ml', 'amadeirado'),
(57, 'PUGLIN', 65, 'n5.jpg', 'novidades', 'Splash Desodorante Colônia Cardamom 200ml', 'citrico'),
(58, 'ANGEL', 28, 'n7.jpg', 'refils', 'Splash Desodorante Colônia Cardamom 200ml', 'floral'),
(59, 'NUVEM', 30, 'n11.jpg', 'refils', 'Splash Desodorante Colônia Cardamom 200ml', 'amadeirado'),
(60, 'TROPIC', 234, 'n13.jpg', 'refils', 'Splash Desodorante Colônia Cardamom 200ml', 'citrico'),
(61, 'egeo', 32, 'n14.jpg', 'refils', 'Splash Desodorante Colônia Cardamom 200ml', 'oriental'),
(62, 'BLEU', 321, '1638852128.jpg', 'novidades', 'Splash Desodorante Colônia Cardamom 200ml', 'frutal'),
(86, 'GABRIELE', 123, '1639304898.jpg', 'promocao', 'Body Splash Desodorante Colônia Cuide-se Bem Boa Noite 200ml', 'floral'),
(87, 'MAN', 178, '1639304985.jpg', 'promocao', 'Secrets Black Desodorante Colônia 75ml', 'amadeirado'),
(88, 'GABRIELE', 144, '1639313601.jpg', 'promocao', 'Kit Presente de Natal Red (2 itens)', 'amadeirado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `adm` int(1) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `senha` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefone` varchar(15) NOT NULL,
  `data_nasc` date NOT NULL,
  `cidade` varchar(45) NOT NULL,
  `estado` varchar(45) NOT NULL,
  `endereco` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `adm`, `nome`, `senha`, `email`, `telefone`, `data_nasc`, `cidade`, `estado`, `endereco`) VALUES
(8, 0, 'Luiza', '123', 'luiza@gmail.com', '12345678', '2021-09-24', 'campo limpo', 'acre', 'etec'),
(105, 0, 'Abner', '123', 'abner@gmail.com', '123456789', '2021-12-15', 'Campo Limpo Paulista', 'São Paulo', 'Estrada Mocyr Grandezoli'),
(107, 0, 'Kauan', '123', 'kauan@gmail.com', '(11) 978654352', '2004-02-07', 'Campo Limpo Paulista', 'São Paulo', 'Estrada Mocyr Grandezoli'),
(108, 1, 'Duda', '123', 'duda@gmail.com', '1140388288', '2003-05-14', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(109, 0, 'Elisa', '123', 'elisa@gmail.com', '119854756321', '2021-12-29', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(110, 0, 'isabelly ', '12345678', 'isabelly@hotmail.com', '1156565656', '2021-12-24', 'CAMPO LIMPO PAULISTA', 'CE', 'rua Pedro Gregório'),
(111, 0, 'Joséfa', '12345cu', 'josefinhamilgrau@gmail.com', '1156565656', '2021-12-24', 'Campo Limpo Paulista', 'SP', 'rua Pedro Gregório'),
(112, 0, 'lulu', '123', 'lulu@gmail.com', '51544646464', '2021-12-11', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(113, 0, 'michele', '123', 'michele@gmail.com', '1140388288', '2021-12-07', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(114, 0, 'kauan', '123', 'kauanfsouza10@gmail.com', '1140388288', '2021-12-07', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(115, 0, 'Isa', '123', 'Isa123@gmail.com', '283982939283923', '2022-08-01', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(116, 0, 'Michele ff', '123', 'michele123@gmail.com', '67890987654567', '2022-08-07', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(117, 0, 'Kaauan', '123', 'kaauan@gmail.com', '343434343434', '2004-03-02', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(118, 0, 'Pedro', '123', 'pedro12@gmail.com', '12323213323', '2004-04-03', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(119, 0, 'Julia', '123', 'Juliaf@gmail.com', '123232323132', '2004-04-02', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(120, 0, 'gustavo henrique', '123', 'gustavo123@gmail.com', '1232323132', '2022-08-09', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório'),
(121, 0, 'Henrique Dos Santos', '123', 'henrique123@gmail.com', '54637289', '2004-03-02', 'CAMPO LIMPO PAULISTA', 'SP', 'rua Pedro Gregório');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
