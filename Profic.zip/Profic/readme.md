O botão de finalizar compra não funciona, pois este é apenas um site fictício.

Para entrar na página como ADM, use o email: duda@gmail.com     senha: 123
(Para acessar as mudanças, basta passar o cursor pelos produtos e novas funções são exibidas ao clicar no icone do usuario)